# Synthetic Proxy-Voting Classification Dataset

500 deliberately authored synthetic notices for training and semantic evaluation.

IMPORTANT: This is NOT an expert-labelled production gold set. It is a controlled semantic training/challenge corpus. It can test whether a classifier learns the intended distinctions, but it cannot establish real-world customer accuracy.

## Ground-truth schema
- votability: VOTABLE / NOT_VOTABLE / UNCERTAIN
- share_blocking: YES / NO / UNKNOWN
- poa_required: YES / NO / UNKNOWN
- deadline_status: OPEN / PASSED / UNKNOWN
- other_restriction: YES / NO / UNKNOWN
- expected_customer_status: deterministic compatibility bucket derived from the fields above

All temporal cases use fixed evaluation date 2026-10-16.

## Files
- synthetic_train_300.csv — labelled training
- synthetic_validation_100.csv — labelled development/tuning
- synthetic_frozen_test_100_BLIND.csv — give to coder only after model/config freeze
- synthetic_frozen_test_100_ANSWER_KEY.csv — reveal only after blind predictions are saved
- synthetic_frozen_test_100.csv — labelled convenience copy; never expose to training/tuning
- synthetic_all_500.csv / .jsonl — full corpus

## Required evaluation protocol
1. Train only on train_300.
2. Tune only on validation_100.
3. Freeze model, prompts/criteria, thresholds and preprocessing.
4. Predict BLIND test_100 and save predictions.
5. Only then reveal the answer key and score.
6. Keep the existing 57 authored semantic cases as a separate challenge set.

Cases intentionally cover negation, superseded terms, amended deadlines, optional-vs-required POA, blocking/no-blocking, multiple simultaneous restrictions, record-date and securities-lending distinctions, re-registration/disclosure restrictions, non-voting corporate-action elections, contradictory information and genuine ambiguity.

All issuer names/notices are fictional.
